import ContactUs from "@/components/ContactSection/ContactUs";
import LetsTalk from "@/components/ContactSection/LetsTalk";
import Copyright from "@/components/HeroSection/Copyright";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact | Outdoor Adventure",
  description: "Contact page of Outdoor Adventure",
};

const page = () => {
  return (
    <>
      <ContactUs />

      <LetsTalk />

      <Copyright />
    </>
  );
};

export default page;
