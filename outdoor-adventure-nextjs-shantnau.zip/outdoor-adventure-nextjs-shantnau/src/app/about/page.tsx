import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Services | Outdoor Adventure",
  description: "Services page of Outdoor Adventure",
};

const page = () => {
  return <></>;
};

export default page;
