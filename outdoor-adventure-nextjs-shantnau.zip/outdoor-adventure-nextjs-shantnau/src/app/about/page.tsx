import Extraordinary from "@/components/AboutSection/Extraordinary";
import OurMisson from "@/components/AboutSection/OurMisson";
import Who from "@/components/AboutSection/Who";
import Copyright from "@/components/HeroSection/Copyright";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "About | Outdoor Adventure",
  description: "About page of Outdoor Adventure",
};

const page = () => {
  return (
    <>
      <Who />

      <OurMisson />

      <Extraordinary />

      <Copyright />
    </>
  );
};

export default page;
