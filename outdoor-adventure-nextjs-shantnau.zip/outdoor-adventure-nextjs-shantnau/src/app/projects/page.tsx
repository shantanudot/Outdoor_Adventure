import OurProjects from "@/components/ProjectsSection/OurProjects";
import WaterSports from "@/components/ProjectsSection/WaterSports";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Projects | Outdoor Adventure",
  description: "Projects page of Outdoor Adventure",
};

const page = () => {
  return (
    <>
      <OurProjects />

      <WaterSports />

      <section></section>
    </>
  );
};

export default page;
