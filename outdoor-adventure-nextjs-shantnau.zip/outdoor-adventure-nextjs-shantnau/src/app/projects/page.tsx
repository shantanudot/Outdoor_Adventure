import Copyright from "@/components/HeroSection/Copyright";
import OurProjects from "@/components/ProjectsSection/OurProjects";
import WaterCataloge from "@/components/ProjectsSection/WaterCataloge";
import WaterSports from "@/components/ProjectsSection/WaterSports";
import WinterCataloge from "@/components/ProjectsSection/WinterCataloge";
import WinterSports from "@/components/ProjectsSection/WinterSports";
import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Projects | Outdoor Adventure",
  description: "Projects page of Outdoor Adventure",
};

export function CarouselSpacing() {
  return (
    <Carousel className="w-full max-w-sm">
      <CarouselContent className="-ml-1">
        {Array.from({ length: 5 }).map((_, index) => (
          <CarouselItem
            key={index}
            className="pl-1 md:basis-1/2 lg:basis-1/3">
            <div className="p-1">
              <Card>
                <CardContent className="flex aspect-square items-center justify-center p-6">
                  <span className="text-2xl font-semibold">{index + 1}</span>
                </CardContent>
              </Card>
            </div>
          </CarouselItem>
        ))}
      </CarouselContent>
      <CarouselPrevious />
      <CarouselNext />
    </Carousel>
  );
}

const page = () => {
  return (
    <>
      <OurProjects />

      <WaterSports />

      <WaterCataloge />

      <WinterSports />

      <WinterCataloge />

      <Copyright />
    </>
  );
};

export default page;
