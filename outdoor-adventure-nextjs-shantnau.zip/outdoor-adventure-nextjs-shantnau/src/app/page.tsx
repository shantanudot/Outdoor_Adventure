import Explore from "@/components/HeroSection/Explore";
import HomeHero from "@/components/HeroSection/HomeHero";
import HomeUpcomingEvents from "@/components/HeroSection/HomeUpcomingEvents";

import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Home | Outdoor Adventure",
  description: "Home page of Outdoor Adventure",
};

const page = () => {
  return (
    <>
      <HomeHero />

      <HomeUpcomingEvents />

      <Explore />

      <section className="grid grid-cols-3">
        <div className=""></div>
        <div className=""></div>
        <div className=""></div>
      </section>
    </>
  );
};

export default page;
