import Copyright from "@/components/HeroSection/Copyright";
import Destination from "@/components/HeroSection/Destination";
import Explore from "@/components/HeroSection/Explore";
import HomeHero from "@/components/HeroSection/HomeHero";
import HomeUpcomingEvents from "@/components/HeroSection/HomeUpcomingEvents";

import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Home | Outdoor Adventure",
  description: "Home page of Outdoor Adventure",
};

const page = () => {
  return (
    <>
      <HomeHero />

      <HomeUpcomingEvents />

      <Explore />

      <Destination />

      <Copyright />
    </>
  );
};

export default page;
