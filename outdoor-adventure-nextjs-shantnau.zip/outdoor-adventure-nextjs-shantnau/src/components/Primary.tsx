const Primary = () => {
  return (
    <>
      <div className="flex w-3 flex-col gap-8">
        <div className="bg-primary h-[3px]"></div>
      </div>
    </>
  );
};

export default Primary;
