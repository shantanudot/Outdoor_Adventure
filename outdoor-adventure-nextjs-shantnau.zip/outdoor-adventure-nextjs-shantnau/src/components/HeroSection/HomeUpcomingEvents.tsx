import { MoveRight } from "lucide-react";
import Image from "next/image";
import { Button } from "../ui/button";

const HomeUpcomingEvents = () => {
  return (
    <>
      <section className="py-28">
        <div className="grid place-items-center gap-6">
          <div className="text-4xl font-bold tracking-wide">
            Upcoming Events
          </div>

          <div className="bg-primary h-[3px] w-[84px]"></div>
        </div>

        <div className="grid grid-cols-2 place-items-center gap-4 px-12 py-8">
          <div className="flex flex-col items-center justify-center gap-4">
            <Image
              src={"/home/everest-camp.jpg"}
              alt=""
              height={338}
              width={450}
              className="home-card-shadow h-[338px] w-[450px] rounded-lg"
            />

            <div className="mt-4 text-xl font-bold">Everest Camp Trek</div>
            <div className="text-center text-lg">
              Fuerat aestu carentem habentia spectent tonitrua mutastis <br />
              locavit liberioris inistra possedit.
            </div>

            <Button className="mx-auto w-1/2 cursor-pointer rounded-full py-6 font-bold uppercase">
              Learn More <MoveRight />
            </Button>
          </div>

          <div className="flex flex-col items-center justify-center gap-4">
            <Image
              src={"/home/walking-holidays.jpg"}
              alt=""
              height={338}
              width={450}
              className="home-card-shadow h-[338px] w-[450px] rounded-lg shadow"
            />

            <div className="mt-4 text-xl font-bold">Walking Holidays</div>
            <div className="text-center text-lg">
              Fuerat aestu carentem habentia spectent tonitrua mutastis <br />
              locavit liberioris inistra possedit.
            </div>

            <Button className="mx-auto w-1/2 cursor-pointer rounded-full py-6 font-bold uppercase">
              Learn More <MoveRight />
            </Button>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomeUpcomingEvents;
