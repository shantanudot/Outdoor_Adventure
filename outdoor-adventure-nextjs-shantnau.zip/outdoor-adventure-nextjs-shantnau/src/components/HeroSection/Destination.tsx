import Image from "next/image";
import { Button } from "../ui/button";

const Destination = () => {
  return (
    <section className="grid grid-cols-3 gap-5 px-28 py-32">
      <div className="">
        <div className="flex flex-col gap-9">
          <div className="text-4xl font-bold">
            Upcoming Tours <br /> & Destination
          </div>
          <div className="bg-primary h-[3px] w-12"></div>
          <div className="mr-2 text-lg">
            Fuerat aestu carentem habentia spectent tonitrua mutastis locavit
            liberioris. Sinistra possedit litora ut nabataeaque. Setucant
            coepyterunt perveniunt animal! Concordi aurea nabataeaque seductaque
            constaque cepit sublime flexi nullus.
          </div>
          <Button className="w-1/2 cursor-pointer rounded-full py-6 font-bold uppercase">
            Learn More
          </Button>
        </div>
      </div>

      <div className="">
        <div className="flex flex-col gap-5">
          <div className="">
            <Image
              src={"/home/upcoming-1.jpg"}
              alt=""
              height={226}
              width={368}
              className="h-[226px] w-[368px] rounded-sm"
            />
          </div>
          <div className="">
            <Image
              src={"/home/upcoming-3.jpg"}
              alt=""
              height={396}
              width={368}
              className="h-[396px] w-[368px] rounded-sm"
            />
          </div>
        </div>
      </div>
      <div className="">
        <div className="flex flex-col gap-5">
          <div className="">
            <Image
              src={"/home/upcoming-2.jpg"}
              alt=""
              height={396}
              width={368}
              className="h-[396px] w-[368px] rounded-sm"
            />
          </div>
          <div className="">
            <Image
              src={"/home/upcoming-4.jpg"}
              alt=""
              height={226}
              width={368}
              className="h-[206px] w-[368px] rounded-sm"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Destination;
