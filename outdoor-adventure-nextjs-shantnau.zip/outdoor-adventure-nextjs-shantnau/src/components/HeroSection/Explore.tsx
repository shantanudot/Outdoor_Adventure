import { MoveRight } from "lucide-react";
import { Button } from "../ui/button";

const Explore = () => {
  return (
    <section className="bg-[url(/home/section-bg.jpg)] bg-cover bg-fixed">
      <div className="grid grid-cols-2 bg-black/60 px-20 py-40">
        <div className=""></div>
        <div className="flex flex-col gap-5">
          <div className="text-4xl font-bold text-white">Explore The World</div>
          <div className="bg-primary h-0.5 w-16"></div>
          <div className="text-lg text-white">
            Diremit mundi mare undae nunc mixtam tanto sibi. Nubes unda
            concordi. Fert his. Recessit mentes praecipites locum caligine sui
            egens erat. Silvas caeli regna.
          </div>
          <Button className="w-1/3 cursor-pointer rounded-full py-6 font-bold uppercase">
            Learn More <MoveRight />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Explore;
