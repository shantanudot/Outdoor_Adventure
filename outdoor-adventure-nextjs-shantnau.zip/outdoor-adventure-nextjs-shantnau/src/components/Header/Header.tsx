import Link from "next/link";
import ThemeToggleButton from "../ui/ThemeToggleButton";
import Image from "next/image";
import { Button } from "../ui/button";

const Header = () => {
  return (
    <header
      className="absolute top-0 right-0 left-0"
      aria-label="app-header">
      <div className="container mx-auto flex items-center justify-between px-6 py-3">
        <Link href={"/"}>
          <Image
            src="/logo.png"
            alt=""
            width={150}
            height={42}
          />
        </Link>

        <nav className="flex items-center gap-6 text-lg text-white">
          <Link
            href={"/"}
            className="hover:text-primary">
            Home
          </Link>

          <Link
            href={"/about"}
            className="hover:text-primary">
            About
          </Link>

          <Link
            href={"/services"}
            className="hover:text-primary">
            Services
          </Link>

          <Link
            href={"/projects"}
            className="hover:text-primary">
            Projects
          </Link>

          <Link
            href={"/contact"}
            className="hover:text-primary">
            Contact
          </Link>

          <Button className="cursor-pointer rounded-full px-11 py-6 font-bold uppercase">
            Take Action
          </Button>
          <ThemeToggleButton />
        </nav>
      </div>
    </header>
  );
};

export default Header;
