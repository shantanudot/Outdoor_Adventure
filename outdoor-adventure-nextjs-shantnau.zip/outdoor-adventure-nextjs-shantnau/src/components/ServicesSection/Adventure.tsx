const Adventure = () => {
  return (
    <section className="flex flex-col items-center gap-6 p-20">
      <div className="text-4xl font-bold">
        It's Time to Start Your Adventures
      </div>
      <div className="bg-primary h-[3px] w-50"></div>
      <div className="text-center text-lg">
        Click edit button to change this text. Lorem ipsum dolor sit amet,
        consectetur adipiscing elit. <br /> Ut elit tellus, luctus ullamcorpe
        pulvinar.
      </div>
    </section>
  );
};

export default Adventure;
