const Services = () => {
  return (
    <section className="bg-[url(/services/services-bg.jpg)] bg-cover bg-no-repeat text-white">
      <div className="grid place-items-center bg-black/30 py-[248px]">
        <div className="text-7xl font-bold tracking-wide">Services</div>
      </div>
    </section>
  );
};

export default Services;
