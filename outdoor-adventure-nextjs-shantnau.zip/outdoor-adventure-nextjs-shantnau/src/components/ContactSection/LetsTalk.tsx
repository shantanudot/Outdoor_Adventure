import { Facebook, Twitter, Youtube } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";

const LetsTalk = () => {
  return (
    <section className="grid grid-cols-2 gap-10 px-48 py-36">
      <div className="flex flex-col gap-6">
        <div className="text-4xl font-bold">We're Ready, Let's Talk.</div>
        <div className="">
          <Input
            className="h-15 rounded-none"
            type="text"
            placeholder="Your Name"
          />
        </div>
        <div className="">
          <Input
            className="h-15 rounded-none"
            type="email"
            placeholder="Email Address"
          />
        </div>
        <div className="">
          <Textarea
            className="rounded-none"
            placeholder="Type your message here."
          />
        </div>
        <div className="">
          <Button className="cursor-pointer rounded-full px-4 py-6 font-bold uppercase">
            SEND MESSAGE
          </Button>
        </div>
      </div>

      <div className="flex flex-col gap-6">
        <div className="text-4xl font-bold">Contact Info</div>
        <div className="">
          <h4 className="text-xl font-bold">Address​</h4>123 Fifth Avenue, NY
          10160, New York, USA
        </div>
        <div className="">
          <h4 className="text-xl font-bold">Email Us</h4>contact@example.com
        </div>
        <div className="">
          <h4 className="text-xl font-bold">Call Us</h4>800-123-456
        </div>

        <div className="text-xl font-bold">Follow Us</div>
        <div className="flex cursor-pointer gap-2">
          <div className="bg-primary flex h-10 w-10 items-center justify-center rounded-[50] hover:bg-gray-500">
            <Facebook color="#ffffff" />
          </div>
          <div className="bg-primary flex h-10 w-10 items-center justify-center rounded-[50] hover:bg-gray-500">
            <Twitter color="#ffffff" />
          </div>
          <div className="bg-primary flex h-10 w-10 items-center justify-center rounded-[50] hover:bg-gray-500">
            <Youtube color="#ffffff" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default LetsTalk;
