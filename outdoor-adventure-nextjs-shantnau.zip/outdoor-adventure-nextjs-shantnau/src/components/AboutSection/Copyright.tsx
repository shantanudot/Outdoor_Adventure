const Copyright = () => {
  return (
    <section>
      <div className="flex flex-col place-items-center gap-6 bg-black px-10 py-11 text-[17px] text-white">
        <div className="">
          123 Fifth Avenue, NY 10160, New York, USA | Phone: 800-123-456 |
          Email: contact@example.com
        </div>
        <div className="">Copyright © 2025 Outdoor Adventure</div>
      </div>
    </section>
  );
};

export default Copyright;
