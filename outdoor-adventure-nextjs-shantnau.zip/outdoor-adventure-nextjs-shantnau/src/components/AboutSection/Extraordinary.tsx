import Primary from "../Primary";

const Extraordinary = () => {
  return (
    <section className="grid grid-cols-2 px-28 pb-24">
      <div className="flex flex-col gap-6">
        <div className="text-2xl font-bold">Extraordinary Experiences</div>
        <div className="bg-primary h-[3px] w-12"></div>
        <div className="">
          Click edit button to change this text. Lorem ipsum dolor sit <br />
          amet, adipiscing elit.
        </div>
        <div className="">
          Click edit button to change this text. Lorem ipsum dolor sit <br />
          amet, consectetur adipiscing elit. Ut elit tellus, luctus nec <br />
          ullamcorper mattis, pulvinar dapibus leo.
        </div>
      </div>

      <div className="flex flex-col gap-6">
        <div className="text-2xl font-bold">Our Core Values</div>
        <div className="bg-primary h-[3px] w-12"></div>
        <div className="">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut <br />
          elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus
          <br /> leo.
        </div>
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-4">
            <Primary />
            Web Design & Development
          </div>
          <div className="flex items-center gap-4">
            <Primary />
            Full-Stack Development
          </div>
          <div className="flex items-center gap-4">
            <Primary />
            App Development
          </div>
        </div>
      </div>
    </section>
  );
};

export default Extraordinary;
