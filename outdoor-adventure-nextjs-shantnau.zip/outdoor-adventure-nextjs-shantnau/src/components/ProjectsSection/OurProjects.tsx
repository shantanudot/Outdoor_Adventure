const OurProjects = () => {
  return (
    <section className="bg-[url(/projects/681b15a786b4386d7b7c34b0_tmpcyznnsg5.jpeg)] bg-cover bg-no-repeat text-white">
      <div className="grid place-items-center bg-black/30 py-[248px]">
        <div className="text-7xl font-bold tracking-wide">Who We Are?</div>
      </div>
    </section>
  );
};

export default OurProjects;
