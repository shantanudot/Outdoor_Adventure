import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import Image from "next/image";

const WaterCataloge = () => {
  return (
    <section className="px-48 py-20">
      <Carousel className="flex">
        <CarouselPrevious />
        <CarouselNext />
        <CarouselContent className="flex items-center">
          <CarouselItem className="basis-1/3">
            <Image
              src="/projects/water-sports-1.jpg"
              alt=""
              height={328}
              width={500}
              className="h-[398] w-[380] rounded-sm"
            />
          </CarouselItem>
          <CarouselItem className="basis-1/3">
            <Image
              src="/projects/water-sports-2.jpg"
              alt=""
              height={398}
              width={500}
              className="h-[398] w-[380] rounded-sm"
            />
          </CarouselItem>
          <CarouselItem className="basis-1/3">
            <Image
              src="/projects/water-sports-3.jpg"
              alt=""
              height={398}
              width={500}
              className="h-[398] w-[380] rounded-sm"
            />
          </CarouselItem>
          <CarouselItem className="basis-1/3">
            <Image
              src="/projects/winter-sports-1.jpg"
              alt=""
              height={398}
              width={500}
              className="h-[398] w-[380] rounded-sm"
            />
          </CarouselItem>
          <CarouselItem className="basis-1/3">
            <Image
              src="/projects/winter-sports-2.jpg"
              alt=""
              height={398}
              width={500}
              className="h-[398] w-[380] rounded-sm"
            />
          </CarouselItem>
          <CarouselItem className="basis-1/3">
            <Image
              src="/projects/winter-sports-3.jpg"
              alt=""
              height={398}
              width={500}
              className="h-[398] w-[380] rounded-sm"
            />
          </CarouselItem>
        </CarouselContent>
      </Carousel>
    </section>
  );
};

export default WaterCataloge;
