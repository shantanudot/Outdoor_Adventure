import Copyright from "@/components/HeroSection/Copyright";
import Adventure from "@/components/ServicesSection/Adventure";
import Backpack from "@/components/ServicesSection/Backpack";
import Services from "@/components/ServicesSection/Services";
import WhyOutdoor from "@/components/ServicesSection/WhyOutdoor";

const page = () => {
  return (
    <>
      <Services />

      <Adventure />

      <Backpack />

      <WhyOutdoor />

      <Copyright />
    </>
  );
};

export default page;
