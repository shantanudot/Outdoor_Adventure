import ContactUs from "@/components/ContactSection/ContactUs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact | Outdoor Adventure",
  description: "Contact page of Outdoor Adventure",
};

const page = () => {
  return (
    <>
      <ContactUs />

      <section className="grid grid-cols-2 px-48 py-36">
        <div className="flex flex-col gap-6">
          <div className="text-4xl font-bold">We're Ready, Let's Talk.</div>
          <div className="">
            <Input
              className="h-15 rounded-none"
              type="text"
              placeholder="Your Name"
            />
          </div>
          <div className="">
            <Input
              className="h-15 rounded-none"
              type="email"
              placeholder="Email Address"
            />
          </div>
          <div className="">
            <Textarea
              className="rounded-none"
              placeholder="Type your message here."
            />
          </div>
          <div className="">
            <Button className="cursor-pointer rounded-full px-4 py-6 font-bold uppercase">
              SEND MESSAGE
            </Button>
          </div>
        </div>

        <div className=""></div>
      </section>
    </>
  );
};

export default page;
