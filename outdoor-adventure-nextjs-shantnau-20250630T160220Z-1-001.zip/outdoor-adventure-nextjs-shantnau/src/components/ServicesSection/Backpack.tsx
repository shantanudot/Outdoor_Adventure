import Image from "next/image";

const Backpack = () => {
  return (
    <section className="">
      <div className="grid grid-cols-2 place-items-center gap-12 px-32 py-6 pb-48">
        <div className="flex flex-col items-center justify-center gap-4">
          <Image
            src={"/services/backpacking.jpg"}
            alt=""
            height={308}
            width={470}
            className="home-card-shadow h-[308px] w-[480px] rounded-sm"
          />

          <div className="mt-4 text-xl font-bold">Everest Camp Trek</div>
          <div className="text-center text-lg">
            Fuerat aestu carentem habentia spectent tonitrua mutastis <br />
            locavit liberioris inistra possedit.
          </div>
        </div>

        <div className="flex flex-col items-center justify-center gap-4">
          <Image
            src={"/services/family-hiking.jpg"}
            alt=""
            height={308}
            width={470}
            className="home-card-shadow h-[308px] w-[480px] rounded-sm"
          />

          <div className="mt-4 text-xl font-bold">Everest Camp Trek</div>
          <div className="text-center text-lg">
            Fuerat aestu carentem habentia spectent tonitrua mutastis <br />
            locavit liberioris inistra possedit.
          </div>
        </div>

        <div className="flex flex-col items-center justify-center gap-4">
          <Image
            src={"/services/water-sports.jpg"}
            alt=""
            height={338}
            width={450}
            className="home-card-shadow h-[308px] w-[480px] rounded-sm shadow"
          />

          <div className="mt-4 text-xl font-bold">Water Sports</div>
          <div className="text-center text-lg">
            Fuerat aestu carentem habentia spectent tonitrua mutastis <br />
            locavit liberioris inistra possedit.
          </div>
        </div>

        <div className="flex flex-col items-center justify-center gap-4">
          <Image
            src={"/services/winter-sports.jpg"}
            alt=""
            height={338}
            width={450}
            className="home-card-shadow h-[308px] w-[480px] rounded-sm shadow"
          />

          <div className="mt-4 text-xl font-bold">Water Sports</div>
          <div className="text-center text-lg">
            Fuerat aestu carentem habentia spectent tonitrua mutastis <br />
            locavit liberioris inistra possedit.
          </div>
        </div>
      </div>
    </section>
  );
};

export default Backpack;
