import Image from "next/image";

const OurMisson = () => {
  return (
    <section className="grid grid-cols-2 px-28 py-28">
      <div className="mt-5 flex flex-col gap-7">
        <div className="text-4xl font-bold">Our MissioN</div>
        <div className="bg-primary h-[3px] w-12"></div>
        <div className="">
          Click edit button to change this text. Lorem ipsum dolor sit <br />
          amet, adipiscing elit.
        </div>
        <div className="">
          Click edit button to change this text. Lorem ipsum dolor sit <br />
          amet, consectetur adipiscing elit. Ut elit tellus, luctus nec <br />
          ullamcorper mattis, pulvinar dapibus leo.
        </div>
      </div>

      <div className="">
        <Image
          src="/about/our-mission.jpg"
          alt=""
          height={328}
          width={500}
          className="home-card-shadow h-[328] w-[515] rounded-lg"
        />
      </div>
    </section>
  );
};

export default OurMisson;
