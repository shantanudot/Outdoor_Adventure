import Image from "next/image";
import { Button } from "../ui/button";

const HomeHero = () => {
  return (
    <>
      <section className="bg-[url(/home/hero-bg.jpg)] bg-cover bg-fixed bg-no-repeat text-white">
        <div className="grid place-items-center bg-black/60 py-60">
          <div className="space-y-8 text-center">
            <div className="text-3xl font-bold tracking-wide">
              Explore the Colourful World
              <div className="mt-2 flex justify-center">
                <div className="bg-primary h-0.5 w-16"></div>
              </div>
            </div>

            <div className="text-7xl font-bold tracking-wide">
              A Wonderful Gift
            </div>

            <Button className="cursor-pointer rounded-full px-11 py-6 font-bold uppercase">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      <section className="h-52 w-full bg-gray-200">
        <div className="flex items-center gap-4">
          <Image
            src="/home/quote-1.png"
            alt=""
            height={220}
            width={220}
            className="pt-12 pl-24"
          />

          <div className="grid self-end text-center text-2xl text-black">
            &quot;Fuerat aestu carentem habentia spectent tonitrua mutastis
            locavit liberioris.&quot;
            <div className="">- Adam Sendler</div>
          </div>
        </div>
      </section>
    </>
  );
};

export default HomeHero;
