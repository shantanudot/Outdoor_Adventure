const WaterSports = () => {
  return (
    <section className="flex flex-col gap-4 px-32 py-24 pb-8">
      <div className="flex items-center gap-4">
        <div className="items-center font-bold">Adventure</div>
        <div className="bg-primary flex h-[3px] w-20"></div>
      </div>
      <div className="flex flex-col text-4xl font-bold">Water Sports</div>
      <div className="">
        Interdum exercitation penatibus, praesentium facilisi accusamus
        fermentum, sagittis.
      </div>
    </section>
  );
};

export default WaterSports;
