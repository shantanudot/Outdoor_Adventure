const ContactUs = () => {
  return (
    <section className="bg-[url(/contact/contact-bg.jpg)] bg-cover bg-no-repeat text-white">
      <div className="grid place-items-center bg-black/30 py-[248px]">
        <div className="text-7xl font-bold tracking-wide">Contact Us</div>
      </div>
    </section>
  );
};

export default ContactUs;
